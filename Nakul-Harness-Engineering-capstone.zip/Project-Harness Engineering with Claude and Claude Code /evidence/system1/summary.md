# Run summary — 20260924_103938

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1162** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6375 | 477 | 0.0088 | 4.4 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6157 | 468 | 0.0085 | 4.7 |
| claim_03_water_damage | incomplete | - | - | 3 | 0 | 9194 | 467 | 0.0115 | 5.5 |
| claim_04_neighbor_injury | routed | liability | high | 6 | 0 | 22305 | 1195 | 0.0283 | 16.0 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14906 | 931 | 0.0196 | 9.6 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 9436 | 646 | 0.0127 | 8.7 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6298 | 491 | 0.0088 | 5.7 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14110 | 811 | 0.0182 | 15.1 |
