from pathlib import Path

content = """# Reflection Brief — Harness Engineering Capstone

**Name:** Nakul Jain
**Date:** 24 September 2026

## Environment

- Model(s): Claude Haiku 4.5 for System 1.
- OS / Python: Linux/WSL, Python 3.13.0.
- Approx. API spend: 0.1162 USD.

"""

Path("reflection-brief.md").write_text(content, encoding="utf-8")
print("REFLECTION FILE CREATED")
