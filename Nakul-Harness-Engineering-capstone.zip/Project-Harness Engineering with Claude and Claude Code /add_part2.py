from pathlib import Path

p = Path("reflection-brief.md")
content = p.read_text(encoding="utf-8")

content += """
## Part 2 — Synthesis

14. **Three layers.** Point to a file/artifact for each layer and justify.
   → Model: shift_monitor/invocation.py — the prompt gives the model the role, hot state, and new defects and asks for a shift report and updated hot-state proposal.
   → Harness: shift_monitor/state.py — HotState, the 5,120-byte budget, validation, and atomic write enforce deterministic boundaries.
   → Orchestration: shift_monitor/pipeline.py — it retrieves new defects, builds the prompt, calls the model, parses the response, updates state, and writes the scratchpad.

15. **Deterministic vs prompt.** Cite one behavior guaranteed in code and one guided by prompt. When is each right?
   → A deterministic behavior is the 5,120-byte hot-state budget and atomic write in shift_monitor/state.py. A prompt-guided behavior is the model's interpretation of defect evidence and generation of the shift report in shift_monitor/invocation.py. Deterministic code is appropriate for safety, limits, and state integrity, while prompts are appropriate for flexible interpretation and reasoning.

16. **Context, two faces.** Compare context management in System 2 and System 4 with cited numbers from both. Same principle, different mechanism — how?
   → System 2 reduced context from 38,708 to 16,893 tokens, a 56.36% reduction, by assembling needed sections and compressing resolved material. System 4 used a 643-byte hot state with a 5,120-byte budget and queried only defects newer than since_ts. Both keep current, useful context small, but System 2 manages context during a support session while System 4 persists bounded state across shifts.

17. **Reliability you can't see in one run.** Name one behavior a test guarantees that a single successful run would not reveal. Why does it matter before shipping?
   → System 1's anti-pattern tests guarantee that the loop does not rely on magic string-membership checks or a hard-coded integer iteration cap and that stop_reason controls termination. A single successful run could pass even if the implementation contained one of these fragile patterns. The tests provide confidence in the implementation pattern across future inputs. Artifact: tests/test_antipatterns.py — 29/29 tests passed.

18. **Blast radius.** Pick one system. What's the blast radius if it misbehaves, and what's the kill switch?
   → In System 4, the model receives recent defects and bounded hot state rather than the entire database. The resulting state is validated against the HotState schema and 5,120-byte budget, and atomic write prevents an oversized payload from replacing existing state. Operationally, the shift run can be stopped by not invoking the run-shift command. Artifacts: shift_monitor/pipeline.py, shift_monitor/state.py, shift_monitor/warm.py.

"""

p.write_text(content, encoding="utf-8")
print("PART 2 ADDED")
