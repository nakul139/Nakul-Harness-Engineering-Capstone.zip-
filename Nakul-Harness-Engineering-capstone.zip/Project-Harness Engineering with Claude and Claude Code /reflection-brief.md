# Reflection Brief — Harness Engineering Capstone

**Name:** Nakul Jain
**Date:** 24 September 2026

## Environment

- Model(s): Claude Haiku 4.5 for System 1.
- OS / Python: Linux/WSL, Python 3.13.0.
- Approx. API spend: 0.1162 USD.


## Part 1 — Per-system

### System 1 — Agentic loop

1. **Loop control.** Quote the stop_reason sequence from one trace. Name the file and function that decides continue-vs-stop, and how.
   → The claim_04_neighbor_injury trace has the sequence tool_use → tool_use → tool_use → tool_use → tool_use → end_turn. Turns 1–5 request tools and turn 6 returns end_turn with no tool calls. The loop uses Claude's structured stop_reason as the control signal rather than inspecting natural-language output. Artifact: runs/20260924_103938/traces/claim_04_neighbor_injury.jsonl.

2. **Anti-pattern.** Name one anti-pattern test_antipatterns.py checks for. What would break in your run if the loop used it?
   → One checked anti-pattern is using a magic string-membership test against model text to drive control flow. This would make loop control dependent on fragile natural-language output instead of structured stop_reason. The tests also reject a hard-coded integer iteration cap as the primary stopping mechanism. Artifact: tests/test_antipatterns.py — 29/29 tests passed.

3. **Tool design.** Pick two tools with overlapping inputs. How do the descriptions prevent misrouting? What did a structured tool error let the agent do that a generic string would not?
   → record_claim_fact and request_clarification both operate on claim information, but their descriptions define different purposes and structured fields. Tool failures return JSON containing is_error and an error_category such as transient or permanent, allowing the agent to adapt instead of treating every failure as an unstructured message. Artifact: claims_intake/tools.py and claims_intake/system_prompt.py.

4. **Your numbers.** Quote the turn count and cost for one claim. How does it differ from the README sample, and why?
   → claim_04_neighbor_injury used 6 turns with an estimated cost of $0.0283, with 22,305 input tokens and 1,195 output tokens. The actual number of interactions and token usage varies by claim and model response. Artifact: runs/20260924_103938/summary.md and the claim_04 trace.

### System 2 — Context strategy

5. **The reduction.** From budget.json: baseline tokens, assembled tokens, reduction %. Which section dominates the assembled context, and why keep it verbatim?
   → The baseline was 38,708 tokens, assembled context was 16,893 tokens, and reduction was 56.36%. The active section dominates with 15,789 tokens, compared with 204 for case_facts, 380 for resolved_refund, and 538 for resolved_subscription. The active issue needs detailed information because it is the current unresolved context. Artifact: runs/20260924-104335/budget.json.

6. **Summarize vs preserve.** State the rule for what gets summarized vs kept byte-exact, citing your per-section token numbers.
   → Older resolved material is compressed while the active issue is retained in much greater detail. The resulting sections were 204 tokens for case_facts, 380 for resolved_refund, 538 for resolved_subscription, and 15,789 for active. Artifact: runs/20260924-104335/budget.json.

7. **Facts block.** Compare eval.jsonl to eval_control.jsonl. Which question regressed, and what does that prove?
   → Q6 regressed in the control evaluation. The expected structured status was in_progress, but the control response failed to provide that structured status. Q1 correctly retrieved the $22.14 refund amount. This demonstrates the value of preserving important structured facts in the active context. Artifact: runs/20260924-104335/eval_control.jsonl.

### System 3 — Claude Code config

8. **Path-scoped rules.** Quote the glob frontmatter from one rule file. Why is it better than a directory-level CLAUDE.md for cross-cutting conventions?
   → The React rule uses paths for src/components/**/* and src/pages/**/* . This scopes React conventions specifically to component and page files instead of applying them universally. Artifact: .claude/rules/react.md.

9. **Forked skill.** Quote the context: fork and allowed-tools lines. What does running forked + read-only buy you? What breaks without it?
   → The skill specifies context: fork and a read-only allowlist beginning with Read, Grep, Glob and restricted Git/GitHub commands. Fork keeps verbose discovery output out of the main session, while the allowlist prevents modification, deployment, pushing or migrations. Artifact: .claude/skills/deploy-check/SKILL.md.

10. **Scope.** From the validator output: project-level vs user-level scope. Give one example of each from this config.
   → The deploy-check skill is project-scoped because it lives at .claude/skills/deploy-check/. The documentation gives ~/.claude/skills/deploy-check-strict/ as a user-level example. The validator was successfully rerun after installing pyyaml and returned OK. Artifact: .claude/skills/deploy-check/SKILL.md.

### System 4 — Orchestration

11. **Push work down.** Defects the SQL query returned vs warm-tier total. Name the indexed query. Why does the model never see the full history?
   → The shift run queried only defects newer than since_ts, with a limit of 50, using SELECT * FROM defects WHERE ts > ? ORDER BY ts DESC LIMIT ?. SQLite performs this filtering before data reaches the model, so the model receives relevant recent defects rather than the complete history. Artifact: shift_monitor/warm.py and shift_monitor/pipeline.py.

12. **Crash recovery.** The resume-vs-fresh decision and its staleness threshold. Why is a fresh start with an injected summary sometimes more reliable than resuming?
   → Recovery chooses resume when the manifest is incomplete and the last step is no more than 30 minutes old. It chooses fresh when there are no steps, the manifest is complete, or the last step is older than 30 minutes. A fresh start can be more reliable for stale state because old partial context may no longer represent the current working set. Artifact: shift_monitor/recovery.py.

13. **Small state.** Byte size of your hot_state.json. Why does the budget matter for a system run once per shift, indefinitely?
   → data/hot_state.json was 643 bytes. The implementation enforces a 5,120-byte hot-state budget and rejects oversized serialized state before replacing the existing file. A bounded state prevents persistent context from growing indefinitely. Artifact: data/hot_state.json and shift_monitor/state.py.


## Part 2 — Synthesis

14. **Three layers.** Point to a file/artifact for each layer and justify.
   → Model: shift_monitor/invocation.py — the prompt gives the model the role, hot state, and new defects and asks for a shift report and updated hot-state proposal.
   → Harness: shift_monitor/state.py — HotState, the 5,120-byte budget, validation, and atomic write enforce deterministic boundaries.
   → Orchestration: shift_monitor/pipeline.py — it retrieves new defects, builds the prompt, calls the model, parses the response, updates state, and writes the scratchpad.

15. **Deterministic vs prompt.** Cite one behavior guaranteed in code and one guided by prompt. When is each right?
   → A deterministic behavior is the 5,120-byte hot-state budget and atomic write in shift_monitor/state.py. A prompt-guided behavior is the model's interpretation of defect evidence and generation of the shift report in shift_monitor/invocation.py. Deterministic code is appropriate for safety, limits, and state integrity, while prompts are appropriate for flexible interpretation and reasoning.

16. **Context, two faces.** Compare context management in System 2 and System 4 with cited numbers from both. Same principle, different mechanism — how?
   → System 2 reduced context from 38,708 to 16,893 tokens, a 56.36% reduction, by assembling needed sections and compressing resolved material. System 4 used a 643-byte hot state with a 5,120-byte budget and queried only defects newer than since_ts. Both keep current, useful context small, but System 2 manages context during a support session while System 4 persists bounded state across shifts.

17. **Reliability you can't see in one run.** Name one behavior a test guarantees that a single successful run would not reveal. Why does it matter before shipping?
   → System 1's anti-pattern tests guarantee that the loop does not rely on magic string-membership checks or a hard-coded integer iteration cap and that stop_reason controls termination. A single successful run could pass even if the implementation contained one of these fragile patterns. The tests provide confidence in the implementation pattern across future inputs. Artifact: tests/test_antipatterns.py — 29/29 tests passed.

18. **Blast radius.** Pick one system. What's the blast radius if it misbehaves, and what's the kill switch?
   → In System 4, the model receives recent defects and bounded hot state rather than the entire database. The resulting state is validated against the HotState schema and 5,120-byte budget, and atomic write prevents an oversized payload from replacing existing state. Operationally, the shift run can be stopped by not invoking the run-shift command. Artifacts: shift_monitor/pipeline.py, shift_monitor/state.py, shift_monitor/warm.py.


## Part 3 — Honest assessment

19. **What broke.** One thing that failed first try in your environment, and how you fixed it.
   → The first System 1 live run failed because anthropic 0.39.0 was incompatible with the installed newer httpx, producing the error Client.__init__() got an unexpected keyword argument proxies. I fixed this by installing httpx 0.27.2, after which the System 1 run completed and produced the 20260924_103938 artifacts. The final run reported an estimated total cost of 0.1162 USD. Artifact: runs/20260924_103938/summary.md.

20. **What you'd change.** One architectural decision you'd make differently, grounded in what you observed.
   → I would add stronger deterministic handling and reporting for incomplete System 1 claims. The actual run produced several incomplete outcomes even though the harness completed successfully. I would add clearer diagnostics so the harness distinguishes infrastructure success from business-level completion. Artifact: runs/20260924_103938/summary.md.

## Test Evidence

- System 1: 29/29 tests passed
- System 2: 30/30 tests passed
- System 3: 35/35 tests passed; validator returned OK
- System 4: 33/33 tests passed
- Total: 127/127 tests passed

## Part 3 — Honest assessment

19. **What broke.** One thing that failed first try in your environment, and how you fixed it.
   → The first System 1 live run failed because anthropic 0.39.0 was incompatible with the installed newer httpx, producing the error Client.__init__() got an unexpected keyword argument proxies. I fixed this by installing httpx 0.27.2, after which the System 1 run completed and produced the 20260924_103938 artifacts. The final run reported an estimated total cost of 0.1162 USD. Artifact: runs/20260924_103938/summary.md.

20. **What you'd change.** One architectural decision you'd make differently, grounded in what you observed.
   → I would add stronger deterministic handling and reporting for incomplete System 1 claims. The actual run produced several incomplete outcomes even though the harness completed successfully. I would add clearer diagnostics so the harness distinguishes infrastructure success from business-level completion. Artifact: runs/20260924_103938/summary.md.

## Test Evidence

- System 1: 29/29 tests passed
- System 2: 30/30 tests passed
- System 3: 35/35 tests passed; validator returned OK
- System 4: 33/33 tests passed
- Total: 127/127 tests passed

## Part 3 — Honest assessment

19. **What broke.** One thing that failed first try in your environment, and how you fixed it.
   → The first System 1 live run failed because anthropic 0.39.0 was incompatible with the installed newer httpx, producing the error Client.__init__() got an unexpected keyword argument proxies. I fixed this by installing httpx 0.27.2, after which the System 1 run completed and produced the 20260924_103938 artifacts. The final run reported an estimated total cost of 0.1162 USD. Artifact: runs/20260924_103938/summary.md.

20. **What you'd change.** One architectural decision you'd make differently, grounded in what you observed.
   → I would add stronger deterministic handling and reporting for incomplete System 1 claims. The actual run produced several incomplete outcomes even though the harness completed successfully. I would add clearer diagnostics so the harness distinguishes infrastructure success from business-level completion. Artifact: runs/20260924_103938/summary.md.

## Test Evidence

- System 1: 29/29 tests passed
- System 2: 30/30 tests passed
- System 3: 35/35 tests passed; validator returned OK
- System 4: 33/33 tests passed
- Total: 127/127 tests passed
